package com.thbs.exception;

public class ProductException extends Exception{
	
	public ProductException(String message) {
		super(message);
	}

}
