package com.thbs.request;

public class DeleteProductRequest {
	
//	private Long 

}
