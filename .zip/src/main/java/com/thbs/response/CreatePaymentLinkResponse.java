package com.thbs.response;

public class CreatePaymentLinkResponse {
	
	

}
