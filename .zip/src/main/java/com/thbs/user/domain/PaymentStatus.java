package com.thbs.user.domain;

public enum PaymentStatus {

	PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
