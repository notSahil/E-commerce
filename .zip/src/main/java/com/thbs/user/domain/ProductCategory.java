package com.thbs.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
